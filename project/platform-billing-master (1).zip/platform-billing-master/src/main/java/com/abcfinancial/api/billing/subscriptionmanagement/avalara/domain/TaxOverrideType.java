package com.abcfinancial.api.billing.subscriptionmanagement.avalara.domain;

public enum TaxOverrideType
{
    None,
    TaxAmount,
    Exemption,
    TaxDate,
    AccruedTaxAmount,
    DeriveTaxable
}
