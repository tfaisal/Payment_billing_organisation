package com.abcfinancial.api.billing.generalledger.enums;

public enum EventType
{
    PAYMENT_PROCESSED, DEPOSIT_PROCESSED, WARN, HOLD
}
