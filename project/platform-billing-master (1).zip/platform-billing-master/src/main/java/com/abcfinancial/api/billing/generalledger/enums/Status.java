package com.abcfinancial.api.billing.generalledger.enums;

public enum Status
{
    NEW,
    INPROCESS,
    SUCCESS,
    FAILED,
    HOLD,
    WARN
}
