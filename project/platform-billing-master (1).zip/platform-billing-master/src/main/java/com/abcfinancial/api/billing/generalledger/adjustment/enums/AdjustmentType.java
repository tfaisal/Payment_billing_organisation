package com.abcfinancial.api.billing.generalledger.adjustment.enums;

public enum AdjustmentType
{
    LATE_FEE,
    SERVICE_FEE,
    CREDIT,
    WAIVE_FEE,
    ERROR_ADJUST
}
