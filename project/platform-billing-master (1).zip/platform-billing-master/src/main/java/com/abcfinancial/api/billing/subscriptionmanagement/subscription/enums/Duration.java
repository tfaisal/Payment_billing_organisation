package com.abcfinancial.api.billing.subscriptionmanagement.subscription.enums;

@Deprecated
public enum Duration
{
    MONTHS, WEEKS, DAYS, YEARS
}
