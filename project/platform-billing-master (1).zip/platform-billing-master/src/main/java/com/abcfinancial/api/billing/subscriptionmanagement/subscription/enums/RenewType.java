package com.abcfinancial.api.billing.subscriptionmanagement.subscription.enums;

public enum RenewType
{
    OPEN,
    TERM
}
