package com.abcfinancial.api.billing.generalledger.enums;

public enum FeeValueType
{
    FLAT,
    PERCENTAGE
}
