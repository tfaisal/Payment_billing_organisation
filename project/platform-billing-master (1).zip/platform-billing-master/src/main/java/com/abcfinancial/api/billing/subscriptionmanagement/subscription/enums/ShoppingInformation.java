package com.abcfinancial.api.billing.subscriptionmanagement.subscription.enums;

public enum ShoppingInformation
{
    ECOMMERCE,
    POS,
    MOTO,
    UNKNOWN
}
