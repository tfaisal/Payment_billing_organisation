package com.abcfinancial.api.billing.generalledger.enums;

public enum PaymentType
{
    DEBIT, CREDIT, DEPOSIT
}
