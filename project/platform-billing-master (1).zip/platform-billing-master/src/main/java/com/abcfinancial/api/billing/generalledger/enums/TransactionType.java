package com.abcfinancial.api.billing.generalledger.enums;

public enum TransactionType
{
    STATEMENT,
    SETTLEMENT,
    PAYMENT,
    ADJUSTMENT,
    INVOICE,
    DEPOSIT
}
