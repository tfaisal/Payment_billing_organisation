package com.abcfinancial.api.billing.subscriptionmanagement.avalara.domain;

public enum AddressCategoryId
{
    Storefront,
    MainOffice,
    Warehouse,
    Salesperson,
    Other,
    SellerRemitsTax,
    MarketplaceRemitsTax,
    NonPhysical
}
