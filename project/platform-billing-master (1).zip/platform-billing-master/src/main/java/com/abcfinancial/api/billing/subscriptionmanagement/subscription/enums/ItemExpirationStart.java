package com.abcfinancial.api.billing.subscriptionmanagement.subscription.enums;

public enum ItemExpirationStart
{
    PURCHASE,
    FIRST_USAGE
}
