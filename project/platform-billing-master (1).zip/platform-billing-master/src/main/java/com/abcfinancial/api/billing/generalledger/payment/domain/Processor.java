package com.abcfinancial.api.billing.generalledger.payment.domain;

public enum Processor
{
    DIMEBOX;
}
