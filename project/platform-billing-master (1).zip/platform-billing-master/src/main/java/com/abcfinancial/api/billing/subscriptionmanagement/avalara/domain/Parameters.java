package com.abcfinancial.api.billing.subscriptionmanagement.avalara.domain;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;

@JsonInclude( JsonInclude.Include.NON_NULL )

public class Parameters implements Serializable
{
}
