package com.abcfinancial.api.billing.subscriptionmanagement.account.domain;

public enum Status
{
    PENDING,
    COMPLETED
}
