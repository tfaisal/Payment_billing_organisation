package com.abcfinancial.api.billing.generalledger.statements.enums;

public enum PaymentTypeEnum
{
    DEBIT, CREDIT, DEPOSIT
}
