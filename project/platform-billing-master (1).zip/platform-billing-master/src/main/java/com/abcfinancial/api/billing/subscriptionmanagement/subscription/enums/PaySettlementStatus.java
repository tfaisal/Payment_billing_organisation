package com.abcfinancial.api.billing.subscriptionmanagement.subscription.enums;

public enum PaySettlementStatus
{
    SETTLEMENT_REQUESTED,
    SETTLEMENT_COMPLETED
}
