package com.abcfinancial.api.billing.generalledger.statements.enums;

public enum EventType
{
    STATEMENT, 
    INVOICE, 
    SETTLEMENT
}
