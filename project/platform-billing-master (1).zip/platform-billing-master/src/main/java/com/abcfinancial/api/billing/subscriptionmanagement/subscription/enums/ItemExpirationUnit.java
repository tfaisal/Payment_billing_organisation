package com.abcfinancial.api.billing.subscriptionmanagement.subscription.enums;

public enum ItemExpirationUnit
{
    DAYS,
    WEEKS,
    MONTHS,
    YEARS
}
