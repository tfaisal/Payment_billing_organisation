package com.abcfinancial.api.billing.subscriptionmanagement.subscription.enums;

public enum SubscriptionTypeEnum
{
    PRIMARY, SECONDARY, FREEZE, RENEW, CLONE, EXPIRE, CANCEL
}
