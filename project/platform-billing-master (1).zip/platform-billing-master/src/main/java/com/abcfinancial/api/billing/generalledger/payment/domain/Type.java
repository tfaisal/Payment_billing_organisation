package com.abcfinancial.api.billing.generalledger.payment.domain;

public enum Type
{
    CREDIT_CARD, 
    BANK_ACCOUNT, 
    CASH
}
