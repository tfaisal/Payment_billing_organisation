package com.abcfinancial.api.billing.generalledger.statements.domain;

public enum Type
{
    Cr,
    Dr,
    None
}

