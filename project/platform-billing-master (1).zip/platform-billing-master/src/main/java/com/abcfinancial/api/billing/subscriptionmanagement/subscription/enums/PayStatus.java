package com.abcfinancial.api.billing.subscriptionmanagement.subscription.enums;

public enum PayStatus
{
    PENDING,
    APPROVED,
    DECLINED,
    CHARGEBACK,
    SCHEDULED,
    REFUND
}
