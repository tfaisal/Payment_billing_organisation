package com.abcfinancial.api.billing.subscriptionmanagement.subscription.enums;

public enum ItemType
{
    AMENITY,
    PRODUCT,
    SERVICE,
    FEE

}
