package com.abcfinancial.api.billing.subscriptionmanagement.subscription.enums;

public enum RecurringType
{
    FIRST,
    REPEAT
}
