package com.abcfinancial.api.billing.subscriptionmanagement.avalara.domain;

public enum AddressTypeId
{
    Location, Salesperson, Marketplace
}
