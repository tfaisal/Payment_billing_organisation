package com.abcfinancial.api.billing.subscriptionmanagement.subscription.valueobject;

import lombok.Data;

@Data

public class RemovedCancelSubscriptionVO extends SubscriptionVO
{

}
