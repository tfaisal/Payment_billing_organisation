package com.abcfinancial.api.billing.generalledger.payment.domain;

public enum Brand
{
    VISA, 
    MASTERCARD, 
    AMEX, 
    DISCOVER;
}
