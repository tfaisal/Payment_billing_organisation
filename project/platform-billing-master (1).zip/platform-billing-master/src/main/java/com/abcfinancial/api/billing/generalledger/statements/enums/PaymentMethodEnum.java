package com.abcfinancial.api.billing.generalledger.statements.enums;

public enum PaymentMethodEnum
{
    EFT, 
    AMEX, 
    VENTIV
}
