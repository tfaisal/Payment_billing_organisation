package com.abcfinancial.api.billing.subscriptionmanagement.account.domain;

public enum PaymentType
{
    VISA,
    MASTER_CARD,
    DISCOVER,
    AMEX
}
